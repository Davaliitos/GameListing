using System.Collections.Generic;
using UnityEngine.UI;

namespace UnityEngine.Replay
{
    /// <summary>
    ///     The top level browser for managing carousels and listings
    /// </summary>
    public class UIBrowser : MonoBehaviour
    {
        public static UIBrowser instance { get; private set; }

        private UICarousel m_CarouselItem;

        private List<UICarousel> m_CarouselItems = new List<UICarousel>();
        private List<Vector2Int> m_CarouselPositions = new List<Vector2Int>();

        private RectTransform m_ContentRectTransform;
        private ScrollRect m_ScrollRect;

        private int CarouselHeight
        {
            get { return m_CarouselItems[0].height; }
        }


        /// <summary>
        ///  Awake is called when the script instance is being loaded.
        /// </summary>
        private void Awake()
        {
            instance = this;
            m_CarouselItem = GetComponentInChildren<UICarousel>();
            m_ScrollRect = GetComponentInChildren<ScrollRect>();
            m_ContentRectTransform = m_ScrollRect.content;
        }

        /// <summary>
        /// Initialize the browser
        /// </summary>
        /// <param name="jsonString">The JSON string to parse into listings</param>
        public void Init(string jsonString)
        {
            CreateListings(jsonString);
        }

        /// <summary>
        ///     Creates the listings from a JSON string
        /// </summary>
        /// <param name="jsonString">The JSON string to parse</param>
        private void CreateListings(string jsonString)
        {
            
            ListingsContainer allListings = JsonUtility.FromJson<ListingsContainer>(jsonString);

            Dictionary<string, List<Listing>> gamesByCategory = new Dictionary<string, List<Listing>>();


            foreach (Listing listing in allListings.listings)
            {
                string category = listing.category;

                if (gamesByCategory.ContainsKey(category))
                {
                    gamesByCategory[category].Add(listing);
                }
                else
                {
                    List<Listing> games = new List<Listing>
                    {
                        listing
                    };
                    gamesByCategory[category] = games;
                }
            }

            foreach(KeyValuePair<string,List<Listing>> entry in gamesByCategory)
            {
                var newCarouselItem = Instantiate(m_CarouselItem, m_CarouselItem.transform.parent);
                newCarouselItem.Init(entry.Key, entry.Value);
                m_CarouselItems.Add(newCarouselItem);
            }

            Destroy(m_CarouselItem.gameObject);

            SetCarouselPositions();
            m_ContentRectTransform.sizeDelta = new Vector2(m_ContentRectTransform.sizeDelta.x, CarouselHeight * m_CarouselItems.Count);
        }

        private void SetCarouselPositions()
        {
            var newPos = Vector2Int.zero;

            for (var i = 0; i < m_CarouselItems.Count; i++)
            {
                m_CarouselPositions.Add(newPos);
                m_CarouselItems[i].SetPosition(newPos);
                newPos += Vector2Int.down * CarouselHeight;
            }
        }
    }
}
