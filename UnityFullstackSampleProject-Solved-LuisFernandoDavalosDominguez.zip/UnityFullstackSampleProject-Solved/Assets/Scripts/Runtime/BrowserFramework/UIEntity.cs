
using System;
using System.Collections;
using UnityEngine.Networking;

namespace UnityEngine.Replay
{
    /// <summary>
    ///     Abstract UI object that contains text and images and a reference to a content Listing
    /// </summary>
    [RequireComponent(typeof(CanvasGroup))]
    public class UIEntity : MonoBehaviour
    {
        protected CanvasGroup m_CanvasGroup;
        protected UIImage[] m_Images;
        protected Listing m_Listing;
        protected RectTransform m_RectTransform;
        protected UIText[] m_Texts;

        /// <summary>
        ///     Awake is called when the script instance is being loaded.
        /// </summary>
        private void Awake()
        {
            m_CanvasGroup = GetComponent<CanvasGroup>();
            m_RectTransform = GetComponent<RectTransform>();
            m_Texts = GetComponentsInChildren<UIText>();
            m_Images = GetComponentsInChildren<UIImage>();
        }

        /// <summary>
        ///     Sets the entity's content based on a Listing
        /// </summary>
        /// <param name="l">The Listing to use</param>
        public virtual void SetData(Listing l)
        {
            m_Listing = l;

            foreach(var image in l.images)
            {
                GetTexture(image.url, (string error) =>
                {
                    Debug.Log("Error: " + error);
                }, (Texture2D texture) =>
                {
                    m_Images[0].SetImage(texture);
                });
            }

            foreach (var text in m_Texts) {
                text.SetText(l.GetText(text.textType));
            }
        }

        private void GetTexture(string url, Action<string> onError, Action<Texture2D> onSuccess)
        {
            StartCoroutine(GetTextureCoroutine(url, onError, onSuccess));
        }

        private IEnumerator GetTextureCoroutine(string url, Action<string> onError, Action<Texture2D> onSuccess)
        {
            UnityWebRequest unityWebRequest = UnityWebRequestTexture.GetTexture(url);
            yield return unityWebRequest.SendWebRequest();
            
            if(unityWebRequest.result == UnityWebRequest.Result.ConnectionError)
            {
                onError(unityWebRequest.error);
            }
            else
            {
                onSuccess(((DownloadHandlerTexture)unityWebRequest.downloadHandler).texture);
            }
        }
    }
}
