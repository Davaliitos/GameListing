using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Replay;

namespace Unity.Metacast.Demo
{
    /// <summary>
    ///     Populate UIBrowser with test json data
    /// </summary>
    public class TestListings : MonoBehaviour
    {
        [SerializeField] private TextAsset m_TestJson;

        readonly string getURL = "http://3.133.120.184:8000/api/v0/games";

        string games;

        /// <summary>
        ///     Start is called on the frame when a script is enabled just
        ///     before any of the Update methods are called the first time.
        /// </summary>
        private async void Start()
        {
            //TODO Instead of a TextAsset pass JSON result from the web server.
            GetGames();
        }

        private void GetGames()
        {
            GetListings(getURL, (string error) =>
            {
                Debug.Log("Error: " + error);
            }, (string games) =>
            {
                UIBrowser.instance.Init(games);
            });
        }

        private void GetListings(string url, Action<string> onError, Action<string> onSuccess)
        {
            StartCoroutine(GetRequest(url, onError, onSuccess));
        }

        private IEnumerator GetRequest(string url, Action<string> onError, Action<string> onSuccess)
        {
            UnityWebRequest unityWebRequest = UnityWebRequest.Get(url);
            yield return unityWebRequest.SendWebRequest();

            if (unityWebRequest.result == UnityWebRequest.Result.ConnectionError)
            {
                onError(unityWebRequest.error);
            }
            else
            {
                onSuccess(unityWebRequest.downloadHandler.text);
            }
        }
    }

}